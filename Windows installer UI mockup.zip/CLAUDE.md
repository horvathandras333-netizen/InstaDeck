# Project notes

## Handoff to Claude Code
Any developer handoff / Claude Code package for this project MUST state that the
installer UI ships with **four accent variants**, and that the accent is a themeable
token, not a hard-coded color:

- Orange `#ff5c1a` (primary / CTA, Utilities)
- Amber `#ffb020` (Media, Security)
- Green `#3ddc84` (Gaming)
- Blue `#5b8cff` (Browsers, Development)

Each variant must work across the whole dark theme (tile ring, icon-mark outline,
version badge, checkbox fill, sidebar dot, glowing CTA).
